<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Đăng nhập hệ thống</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            display: grid;
            place-items: center;
            padding: 20px;
            background: linear-gradient(135deg, #eef3ff, #f8faff 55%, #e8efff);
            color: #1b2540;
            font-family: Arial, Helvetica, sans-serif;
        }
        .login-card {
            width: min(420px, 100%);
            padding: 38px;
            border: 1px solid #e6eaf3;
            border-radius: 18px;
            background: #fff;
            box-shadow: 0 18px 55px #263b6818;
        }
        .brand {
            width: 48px; height: 48px; display: grid; place-items: center;
            margin-bottom: 22px; border-radius: 14px;
            background: #e9eeff; color: #304b9b; font-size: 22px; font-weight: 800;
        }
        h1 { margin: 0 0 8px; font-size: 27px; }
        .subtitle { margin: 0 0 27px; color: #788198; font-size: 14px; line-height: 1.5; }
        label { display: block; margin: 16px 0 7px; font-size: 13px; font-weight: 700; }
        input {
            width: 100%; height: 46px; padding: 0 13px; border: 1px solid #dce1ec;
            border-radius: 8px; outline: none; font: inherit;
        }
        input:focus { border-color: #526fd5; box-shadow: 0 0 0 3px #526fd51a; }
        button {
            width: 100%; height: 46px; margin-top: 23px; border: 0; border-radius: 8px;
            background: #263f8b; color: #fff; font-size: 15px; font-weight: 700; cursor: pointer;
        }
        button:hover { background: #1b3278; }
        .hint { margin: 18px 0 0; color: #8b92a4; text-align: center; font-size: 12px; }
        @media (max-width: 420px) { .login-card { padding: 28px 22px; } }
    </style>
</head>
<body>
    <main class="login-card">
        <div class="brand" aria-hidden="true">CG</div>
        <h1>Đăng nhập</h1>
        <p class="subtitle">Nhập thông tin tài khoản để tiếp tục vào hệ thống.</p>

        <form action="${pageContext.request.contextPath}/login" method="post">
            <label for="username">Tên đăng nhập</label>
            <input id="username" name="username" type="text" autocomplete="username"
                   placeholder="Nhập tên đăng nhập" required>

            <label for="password">Mật khẩu</label>
            <input id="password" name="password" type="password" autocomplete="current-password"
                   placeholder="Nhập mật khẩu" required>

            <button type="submit">Đăng nhập</button>
        </form>
        <p class="hint">Bài thực hành JSP / Servlet · Tomcat 10+</p>
    </main>
</body>
</html>
