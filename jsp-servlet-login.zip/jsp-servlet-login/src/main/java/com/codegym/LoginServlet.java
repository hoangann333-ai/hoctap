package com.codegym;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "LoginServlet", urlPatterns = "/login")
public class LoginServlet extends HttpServlet {
    private static final String USERNAME = "admin";
    private static final String PASSWORD = "admin";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        boolean authenticated = USERNAME.equals(username) && PASSWORD.equals(password);
        String contextPath = request.getContextPath();
        String title = authenticated ? "Đăng nhập thành công" : "Đăng nhập thất bại";
        String message = authenticated ? "Welcome admin to website" : "Login Error";
        String color = authenticated ? "#16834a" : "#c62828";

        response.getWriter().printf("""
                <!doctype html>
                <html lang="vi">
                <head>
                  <meta charset="utf-8">
                  <meta name="viewport" content="width=device-width, initial-scale=1">
                  <title>%s</title>
                  <style>
                    * { box-sizing: border-box; }
                    body { margin: 0; min-height: 100vh; display: grid; place-items: center;
                           background: #f4f7fb; font-family: Arial, sans-serif; color: #19233b; }
                    main { width: min(440px, calc(100%% - 32px)); padding: 38px 30px; text-align: center;
                           background: #fff; border-radius: 16px; box-shadow: 0 14px 40px #1a2b4a18; }
                    .mark { width: 54px; height: 54px; margin: 0 auto 16px; display: grid; place-items: center;
                            border-radius: 50%%; background: %s18; color: %s; font-size: 26px; }
                    h1 { margin: 0 0 12px; color: %s; font-size: 23px; }
                    p { margin: 0 0 24px; color: #68738a; line-height: 1.6; }
                    a { display: inline-block; padding: 11px 18px; border-radius: 8px; background: #243b80;
                        color: #fff; text-decoration: none; font-weight: 700; }
                    a:hover { background: #172b69; }
                  </style>
                </head>
                <body><main>
                  <div class="mark">%s</div>
                  <h1>%s</h1>
                  <p>%s</p>
                  <a href="%s/">Quay lại trang đăng nhập</a>
                </main></body>
                </html>
                """, escapeHtml(title), color, color, color,
                authenticated ? "✓" : "!", escapeHtml(title), escapeHtml(message),
                escapeHtml(contextPath));
    }

    private static String escapeHtml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}
