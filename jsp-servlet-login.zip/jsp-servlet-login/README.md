# JSP / Servlet Login

Dự án Maven Web App tương thích Jakarta Servlet 6.0 và Apache Tomcat 10.1+.

## Yêu cầu

- JDK 17+
- Apache Maven
- Apache Tomcat 10.1+

## Đóng gói

Mở terminal tại thư mục dự án, chạy:

```bash
mvn clean package
```

Nếu Maven build thành công, file WAR nằm tại `target/jsp-servlet-login.war`.

## Chạy trên Tomcat

Chép WAR vào thư mục `webapps` của Tomcat rồi khởi động Tomcat. Truy cập:

```
http://localhost:8080/jsp-servlet-login/
```

- Tài khoản đúng: `admin` / `admin`
- Thử nhập sai để xem thông báo `Login Error`

Servlet nhận dữ liệu bằng POST tại `/login`. Đây là tài khoản cố định chỉ dành cho bài thực hành, không dùng cho hệ thống thật.
