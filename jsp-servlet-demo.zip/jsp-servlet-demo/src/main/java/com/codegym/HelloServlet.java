package com.codegym;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "HelloServlet", urlPatterns = "/hello")
public class HelloServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String contextPath = request.getContextPath();

        try (PrintWriter out = response.getWriter()) {
            out.println("<!doctype html>");
            out.println("<html lang="vi"><head><meta charset="UTF-8">");
            out.println("<meta name="viewport" content="width=device-width, initial-scale=1">");
            out.println("<title>Hello Servlet</title></head>");
            out.println("<body style="font-family:Arial,sans-serif;text-align:center;margin:10vh 1rem;background:#f8fafc">");
            out.println("<h1 style="color:#1b2a7a">Chào mừng bạn đến với Servlet đầu tiên!</h1>");
            out.println("<p style="color:#f15a24;font-size:1.1rem">Ứng dụng đang chạy trên Tomcat 10.1+.</p>");
            out.println("<p><a href="" + contextPath + "/index.jsp">Quay lại trang chủ JSP</a></p>");
            out.println("</body></html>");
        }
    }
}
