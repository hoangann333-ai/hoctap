<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.time.ZonedDateTime, java.time.format.DateTimeFormatter" %>
<%
    ZonedDateTime serverNow = ZonedDateTime.now();
    String formattedTime = serverNow.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss z"));
    String zone = serverNow.getZone().getId();
%>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="1">
    <title>Thời gian hệ thống</title>
    <style>
        * { box-sizing: border-box; }
        body {
            min-height: 100vh;
            margin: 0;
            display: grid;
            place-items: center;
            padding: 24px;
            background: #f1f5f9;
            color: #1e293b;
            font-family: Arial, Helvetica, sans-serif;
        }
        main {
            width: min(100%, 680px);
            padding: clamp(28px, 6vw, 56px);
            border-radius: 20px;
            background: #fff;
            box-shadow: 0 18px 55px rgba(15, 23, 42, .12);
            text-align: center;
        }
        .label { color: #64748b; font-size: .95rem; letter-spacing: .08em; text-transform: uppercase; }
        h1 { margin: 12px 0 24px; color: #1b2a7a; font-size: clamp(1.8rem, 5vw, 2.7rem); }
        .clock {
            margin: 0;
            color: #f15a24;
            font-size: clamp(2rem, 8vw, 4.2rem);
            font-weight: 700;
            font-variant-numeric: tabular-nums;
        }
        .date { margin: 12px 0 0; color: #475569; font-size: 1.1rem; }
        .zone { margin: 8px 0 28px; color: #64748b; font-size: .9rem; }
        .button {
            display: inline-block;
            padding: 12px 22px;
            border-radius: 8px;
            background: #1b2a7a;
            color: #fff;
            font-weight: 600;
            text-decoration: none;
        }
        .button:hover { background: #2439a0; }
    </style>
</head>
<body>
    <main>
        <div class="label">Java Web · JSP / Servlet</div>
        <h1>Thời gian hệ thống hiện tại</h1>
        <p class="clock"><%= formattedTime %></p>
        <p class="date">Thời gian được lấy từ máy chủ Tomcat.</p>
        <p class="zone">Múi giờ của máy chủ: <%= zone %></p>
        <a class="button" href="<%= request.getContextPath() %>/hello">Kiểm tra HelloServlet</a>
    </main>
</body>
</html>
