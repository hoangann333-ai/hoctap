# JSP Servlet Demo — Tomcat 10.1+

Ứng dụng Maven Web hiển thị thời gian hiện tại của máy chủ trên trang JSP. Trang tự tải lại mỗi giây. Nút trên trang mở `HelloServlet` để kiểm tra Jakarta Servlet.

## Yêu cầu

- JDK 17 trở lên
- Apache Maven 3.8+
- Apache Tomcat 10.1+

## Đóng gói

Mở terminal tại thư mục chứa `pom.xml` rồi chạy:

```bash
mvn clean package
```

Khi Maven báo `BUILD SUCCESS`, file triển khai nằm tại `target/jsp-servlet-demo.war`.

## Chạy bằng Tomcat

Chép `target/jsp-servlet-demo.war` vào thư mục `webapps` của Tomcat, sau đó khởi động Tomcat:

- Windows: chạy `bin\startup.bat`
- macOS/Linux: chạy `bin/startup.sh`

Mở trình duyệt:

- Trang JSP: http://localhost:8080/jsp-servlet-demo/
- Servlet: http://localhost:8080/jsp-servlet-demo/hello

Tomcat 10 dùng `jakarta.servlet.*`; dự án này khai báo Servlet API 6.0 và JSP API 3.1 ở scope `provided` vì Tomcat cung cấp chúng khi chạy ứng dụng.
